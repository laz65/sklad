<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>



<?php

$connection = pg_connect ("dbname=asterisk user='asterisk' password='12345' ");

if(isset($_FILES["myfile"])) 
{ 
    $myfile = $_FILES["myfile"]["tmp_name"]; 
    $error_flag = $_FILES["myfile"]["error"]; 
	copy ($myfile, "/tmp/vremen.tmp") ; 
	$err = 0;	
	echo "Получаем содержимое файла"; 
    if(!($fp = fopen("/tmp/vremen.tmp","r")))	echo "<META HTTP-EQUIV=\"Refresh\" content =\"2; URL='import.php'\">" ;		
	while (($data = fgetcsv($fp, 512, ";")) !== FALSE) 
	{
	    $num = count($data);
//		echo "Zapis $num";
    	$row++;
        if ($num == 16)
        {    
	    	if (!pg_query($connection, "INSERT INTO sklad( data_izmen, stan, tip, model, ser, inv, data_priyom, misto, centr, viddil, data_vidach, nomer, zrobiv, vidav, otrimav) VALUES ('$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]', '$data[5]', '$data[6]', '$data[7]', '$data[8]', '$data[9]', '$data[10]', '$data[11]', '$data[12]', '$data[13]', '$data[14]' );"))
			{
				echo "<span class=\"стиль4\">Запис '$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]', '$data[5]', '$data[6]', '$data[7]', '$data[8]', '$data[9]', '$data[10]', '$data[11]', '$data[12]', '$data[13]', '$data[14]' неможливо занести в базу. </span><br/>";
				$err++;
			};
		} 
		else
		{
			echo "<h3><span class=\"стиль4\">ЗАПИС ПОВИНЕН МАТИ ФОРМУ: телефон, номер, сума_боргу<br />";
			echo "КОЖЕН ЗАПИС НА ОКРЕМІЙ СТРОЦІ ТІЛЬКИ ЦИФРИ ТА КОМА,<br />";
			echo "БЕЗ СТОРОННІХ СИМВОЛІВ!!! ПЕРЕВІРТЕ ФАЙЛ!!!.</span></h3>";
			$err = 99999999;
			break;
		}        
	}
	fclose($fp);	 
	unlink("/tmp/vremen.tmp") ; 
}

pg_close($connection);
?>
         <FORM ENCTYPE="multipart/form-data" ACTION="" METHOD=POST>
          4. Виберіть файл:
          <input name="myfile" type="file" />
          <input name="submit" type="submit" style="height: 25px" value="ЗАВАНТАЖИТИ" />
		 </form>

               
</body>
</html>
