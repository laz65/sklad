﻿<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Обладнання в ремонті в ЦІТ</title>
<style type="text/css">
<!--
.стиль1 {
	color: #000066;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<?php
$connection = pg_connect("dbname=asterisk user=asterisk password=12345");
$result=pg_query($connection, "select * from sklad  where  stan != 'Видано' order by centr;");
?>


<p align="center" class="стиль1">Обладнання, яке знаходиться на обслуговуванні або ремонті в ЦІТ. </p>
<table width="100%" border="3" align="center" cellpadding="0" cellspacing="0" bordercolor="#66CCCC" class="style20">
  <tr>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Центр</div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Підрозділ</div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Тип обладн. </div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Модель</div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Сер №</div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Інв № </div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Наряд № </div></td>
    <td  bordercolor="#66CCCC" bgcolor="#66CCCC"><div align="center">Стан</div></td>
  </tr>
<?php 
while ($db=pg_fetch_array($result)):
?>	
  <tr>
    <td bordercolor="#66CCCC"><?php echo $db['centr']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['viddil']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['tip']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['model']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['ser']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['inv']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['nomer']; ?></td>
    <td bordercolor="#66CCCC"><?php echo $db['stan']; ?></td>
  </tr>
<?php
endwhile;
pg_close($connection); 
?>
</table>
</body>
</html>
