<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 11">
<link rel=File-List href="Страница.files/filelist.xml">
<style id="Blank_12655_Styles">
<!--table
	{mso-displayed-decimal-separator:"\,";
	mso-displayed-thousand-separator:" ";}
.стиль1 {
	color: #FF0000;
	font-weight: bold;
}
.xl24126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:14.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl25126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl26126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:14.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl27126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl28126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl29126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl30126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl31126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl32126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:normal;}
.xl35126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl36126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl38126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl39126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl41126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl42126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl43126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl44126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl45126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl46126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl47126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl48126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl51126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl52126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl53126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl54126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl55126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl57126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl58126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl59126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl62126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl63126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl64126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl65126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
-->
</style>
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
x\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--></head>

<body>
<!--[if !excel]>&nbsp;&nbsp;<![endif]-->
<!--Следующие сведения были подготовлены мастером публикации веб-страниц
Microsoft Office Excel.-->
<!--При повторной публикации этого документа из Excel все сведения между тегами
DIV будут заменены.-->
<!----------------------------->
<!--НАЧАЛО ФРАГМЕНТА ПУБЛИКАЦИИ МАСТЕРА ВЕБ-СТРАНИЦ EXCEL -->
<!----------------------------->

<div id="Blank_12655" align=center x:publishsource="Excel">
<?php
$login = $_SERVER['REMOTE_USER'];	
$connection = pg_connect("dbname=asterisk user=asterisk password=12345");

$data = rtrim(`sudo -i date +%d/%m/%Yp.`);
$vrem = rtrim(`sudo -i date +%y%m%d/`);
$result2=pg_query($connection, "select nomer from sklad where data_priyom  = '$data';");
$nomer0=pg_num_rows($result2)+1;
$nomer = $vrem . $nomer0;

// $nomer = $_POST['nomer'];

 $centr = $_POST['centry'];
 $viddil = $_POST['pidr'];

$result2=pg_query($connection, "select misto from centry where centr = '$centr';");
$db2=pg_fetch_array($result2);
 $misto = $db2['misto'];

 $telefon = $_POST['telefon'];
 $podav = $_POST['podav'];
 
$result2=pg_query($connection, "select rabotnik from rabotniki where login = '$login';");
$db2=pg_fetch_array($result2);
$prinav=$db2['rabotnik'] ;
 $prim = $_POST['prim'];
 $tip = $_POST['tipy'];
 $model = $_POST['model'];
 $inv = $_POST['inv'];
 $ser = $_POST['ser'];
 $kompl = $_POST['kompl']; 

$result2=pg_query($connection, "select nomer from sklad where ser  = '$ser' and inv = '$inv' and stan != 'Видано';");
$db2=pg_fetch_array($result2);
$nomer0=$db2['nomer'] ;
if(pg_num_rows($result2) > 0) echo "<span class=\"стиль1\">На це обладнання вже був виписаний наряд номер $nomer0. Наряд не занесено в базу!</span>"; 
else
if (!pg_query($connection, "insert into sklad (data_priyom, prinav, stan, tip, model, ser, inv, misto, centr, viddil, nomer, prim, telefon, kompl, podav) values ('$data', '$prinav', 'На складі чекає ремонту', '$tip', '$model', '$ser', '$inv', '$misto', '$centr', '$viddil', '$nomer', '$prim', '$telefon', '$kompl', '$podav');")) echo " НЕ ВДАЛОСЬ ЗАПИСАТИ НАРЯД В БАЗУ!!! " 
 
 ?>
<table x:str border=0 cellpadding=0 cellspacing=0 width=608 class=xl28126551
 style='border-collapse:collapse;table-layout:fixed;width:462pt'>
  <col class=xl28126551 width=26 style='mso-width-source:userset;mso-width-alt:
 950;width:20pt'>
  <col class=xl28126551 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
  <col class=xl28126551 width=20 style='mso-width-source:userset;mso-width-alt:
 731;width:15pt'>
  <col class=xl28126551 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
  <col class=xl28126551 width=28 style='mso-width-source:userset;mso-width-alt:
 1024;width:21pt'>
  <col class=xl28126551 width=24 span=3 style='mso-width-source:userset;
 mso-width-alt:877;width:18pt'>
  <col class=xl28126551 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
  <col class=xl28126551 width=19 style='mso-width-source:userset;mso-width-alt:
 694;width:14pt'>
  <col class=xl28126551 width=26 style='mso-width-source:userset;mso-width-alt:
 950;width:20pt'>
  <col class=xl28126551 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
  <col class=xl28126551 width=23 style='mso-width-source:userset;mso-width-alt:
 841;width:17pt'>
  <col class=xl28126551 width=25 style='mso-width-source:userset;mso-width-alt:
 914;width:19pt'>
  <col class=xl28126551 width=46 style='mso-width-source:userset;mso-width-alt:
 1682;width:35pt'>
  <col class=xl28126551 width=6 style='mso-width-source:userset;mso-width-alt:
 219;width:5pt'>
  <col class=xl28126551 width=17 style='mso-width-source:userset;mso-width-alt:
 621;width:13pt'>
  <col class=xl28126551 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
  <col class=xl28126551 width=23 style='mso-width-source:userset;mso-width-alt:
 841;width:17pt'>
  <col class=xl28126551 width=25 style='mso-width-source:userset;mso-width-alt:
 914;width:19pt'>
  <col class=xl28126551 width=30 style='mso-width-source:userset;mso-width-alt:
 1097;width:23pt'>
  <col class=xl28126551 width=24 style='mso-width-source:userset;mso-width-alt:
 877;width:18pt'>
  <col class=xl28126551 width=21 style='mso-width-source:userset;mso-width-alt:
 768;width:16pt'>
  <col class=xl28126551 width=26 style='mso-width-source:userset;mso-width-alt:
 950;width:20pt'>
  <col class=xl28126551 width=41 style='mso-width-source:userset;mso-width-alt:
 1499;width:31pt'>
  <tr height=25 style='height:18.75pt'>
    <td height=25 class=xl24126551 colspan=3 width=68 style='height:18.75pt;
  width:52pt'>Наряд</td>
    <td class=xl25126551 width=22 style='width:17pt'>&nbsp;</td>
    <td class=xl25126551 colspan=4 width=100 style='width:75pt'>Замовлення №</td>
    <td colspan=5 class=xl25126551 width=112 style='width:85pt'><div align="center"><?php echo $nomer ; ?> </div></td>
    <td class=xl25126551 width=25 style='width:19pt'>&nbsp;</td>
    <td class=xl39126551 width=46 style='width:35pt'>&nbsp;</td>
    <td class=xl25126551 width=6 style='width:5pt'>&nbsp;</td>
    <td class=xl25126551 width=17 style='width:13pt'>&nbsp;</td>
    <td class=xl25126551 width=22 style='width:17pt'>&nbsp;</td>
    <td class=xl25126551 width=23 style='width:17pt'>&nbsp;</td>
    <td class=xl25126551 width=25 style='width:19pt'>&nbsp;</td>
    <td colspan=4 class=xl39126551 width=101 style='width:77pt' x:num><?php echo $data ; ?></td>
    <td class=xl25126551 width=41 style='width:31pt'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl29126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl30126551 colspan=4 style='border-right:.5pt solid black'>Зміст
      заявки</td>
    <td colspan=20 class=xl38126551 style='border-right:.5pt solid black;
  border-left:none'><?php echo $prim ; ?></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551 colspan=3><span
  style='mso-spacerun:yes'> </span>Підрозділ</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551 colspan=3><span style='mso-spacerun:yes'> </span>Пристрій</td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl42126551 colspan=9>Комплектуючі та витратні матеріали</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>     </span>Центр</td>
    <td colspan=4 class=xl43126551><?php echo $centr ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>            </span>ТИП</td>
    <td colspan=4 class=xl43126551><?php echo $tip ; ?></td>
    <td class=xl28126551></td>
    <td class=xl44126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl45126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Відділ</td>
    <td colspan=4 class=xl39126551><?php echo $viddil ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>        </span>Модель</td>
    <td colspan=4 class=xl39126551><?php echo $model ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl41126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl46126551>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Група</td>
    <td colspan=4 class=xl43126551>&nbsp;</td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>        </span>Інв. №</td>
    <td colspan=4 class=xl32126551 width=116 style='border-right:.5pt solid black;
  width:88pt' x:num><?php echo $inv ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl41126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>                </span>Місто</td>
    <td colspan=4 class=xl39126551><?php echo $misto ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>       </span>Сер. №</td>
    <td colspan=4 class=xl39126551><?php echo $ser ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl41126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>          </span>Телефон</td>
    <td colspan=4 class=xl39126551><?php echo $telefon ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>  </span>Компл-сть</td>
    <td colspan=4 class=xl38126551 style='border-right:.5pt solid black'><?php echo $kompl ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl41126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>   </span>Подав заявку</td>
    <td colspan=4 class=xl39126551><?php echo $podav ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>   </span>Од.виміру</td>
    <td colspan=4 class=xl38126551 style='border-right:.5pt solid black'>шт.</td>
    <td class=xl28126551></td>
    <td class=xl46126551>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'>Прийняв заявку</td>
    <td colspan=4 class=xl39126551 x:str="Канюка "><?php echo $prinav ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>     </span>Кількість</td>
    <td colspan=4 class=xl38126551 style='border-right:.5pt solid black' x:num>1</td>
    <td class=xl28126551></td>
    <td class=xl29126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl41126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551
  x:str="                                                                                                                                                                                                                                                                                  "></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl44126551 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black'><span style='mso-spacerun:yes'> </span>Виконавец<span
  style='display:none'>ь</span></td>
    <td class=xl44126551 colspan=3 style='border-right:.5pt solid black'>Дата
      початку</td>
    <td class=xl44126551 colspan=4 style='border-right:.5pt solid black'>Дата
      закінчення</td>
    <td colspan=7 rowspan=2 class=xl48126551 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'><span style='mso-spacerun:yes'>    </span>Діагноз та виконані роботи</td>
    <td colspan=6 rowspan=2 class=xl48126551 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'><span style='mso-spacerun:yes'>   </span>Затрачені матеріали</td>
    <td colspan=2 class=xl48126551 style='border-right:.5pt solid black;
  border-left:none'><span style='mso-spacerun:yes'>     </span>Підпис</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl53126551 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black'><span style='mso-spacerun:yes'>     </span>(П.І.Б.)</td>
    <td class=xl53126551 colspan=3 style='border-right:.5pt solid black'><span
  style='mso-spacerun:yes'>     </span>роботи</td>
    <td class=xl53126551 colspan=3><span style='mso-spacerun:yes'>       </span>роботи</td>
    <td class=xl52126551>&nbsp;</td>
    <td colspan=2 class=xl54126551 style='border-right:.5pt solid black;
  border-left:none'>виконавця</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl44126551 style='height:12.75pt;border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl46126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl53126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl53126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl44126551 style='height:12.75pt;border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl44126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl46126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl46126551>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl46126551>&nbsp;</td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl58126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl54126551>&nbsp;</td>
    <td class=xl55126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl53126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl44126551 style='height:12.75pt;border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-left:none'>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl45126551>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl46126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
    <td class=xl46126551 style='border-left:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl46126551>&nbsp;</td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl53126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl53126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl25126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
  </tr>
  <tr height=25 style='height:18.75pt'>
    <td height=25 class=xl26126551 colspan=6 style='height:18.75pt'>Картка видачі</td>
    <td class=xl28126551 colspan=4>Замовлення №</td>
    <td colspan=3 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=I1"><?php echo $nomer ; ?></td>
    <td class=xl28126551></td>
    <td class=xl28126551 colspan=6><span style='mso-spacerun:yes'> </span>Дата та
      час приймання</td>
    <td colspan=4 class=xl57126551 x:num x:fmla="=U1"><?php echo $data ; ?></td>
    <td class=xl28126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551 colspan=3><span
  style='mso-spacerun:yes'> </span>Підрозділ</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551 colspan=3><div align="center"><span style='mso-spacerun:yes'> </span>Пристрій</div></td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl42126551 colspan=9>Комплектуючі та витратні матеріали</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>     </span>Центр</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=E4"><?php echo $centr ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>            </span>ТИП</td>
    <td colspan=4 class=xl55126551 x:fmla="=L4"><?php echo $tip ; ?></td>
    <td class=xl28126551></td>
    <td class=xl44126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl45126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Відділ</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=E5"><?php echo $viddil ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>        </span>Модель</td>
    <td colspan=4 class=xl36126551 x:fmla="=L5"><?php echo $model ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl41126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl46126551>&nbsp;</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl47126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Група</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=E7"><?php echo $grupa ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>        </span>Інв. №</td>
    <td colspan=4 class=xl35126551 style='border-right:.5pt solid black' x:num
  x:fmla="=L7"><?php echo $inv ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl30126551>&nbsp;</td>
    <td class=xl41126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>                </span>Місто</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=E8"><?php echo $misto ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>       </span>Сер. №</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=L8"><?php echo $ser ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl41126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>          </span>Телефон</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=E9"><?php echo $telefon ; ?></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>  </span>Компл-сть</td>
    <td colspan=4 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=L9"><?php echo $kompl ; ?></td>
    <td class=xl28126551></td>
    <td class=xl29126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl30126551 style='border-top:none'>&nbsp;</td>
    <td class=xl41126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl44126551 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black' x:str="№ наклдн / ">№ наклдн /<span
  style='mso-spacerun:yes'> </span></td>
    <td class=xl44126551 colspan=10>Дата-час отримання послуги обо пристр<span
  style='display:none'>ою</span></td>
    <td colspan=8 rowspan=2 class=xl48126551 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'><span style='mso-spacerun:yes'>   </span>Отримав (П.І.Б. замовника)</td>
    <td colspan=4 rowspan=2 class=xl48126551 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>Підпис замовника</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl53126551 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black'><span style='mso-spacerun:yes'> </span>№ запису</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551 colspan=8><span style='mso-spacerun:yes'>   </span>(заповнюється замовником)</td>
    <td class=xl51126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl44126551 style='height:12.75pt;border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
    <td class=xl44126551 style='border-top:none;border-left:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl25126551 style='border-top:none'>&nbsp;</td>
    <td class=xl45126551 style='border-top:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl53126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
    <td class=xl53126551 style='border-left:none'>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl51126551>&nbsp;</td>
    <td class=xl52126551>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551 colspan=7 x:str="Черговий сектору ТЗ та ОК ">Черговий
      сектору ТЗ та ОК<span style='mso-spacerun:yes'> </span></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'> </span>ЦІТіТЗ</td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl62126551 style='height:12.75pt'>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
    <td class=xl25126551>&nbsp;</td>
  </tr>
  <tr height=25 style='height:18.75pt'>
    <td height=25 class=xl26126551 colspan=4 style='height:18.75pt'>Розписка</td>
    <td class=xl28126551 colspan=4>Замовлення №</td>
    <td colspan=3 class=xl59126551 style='border-right:.5pt solid black'
  x:fmla="=I1"><?php echo $nomer ; ?></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551 colspan=6>Дата та час приймання</td>
    <td colspan=4 class=xl57126551 x:num x:fmla="=U1"><?php echo $data ; ?></td>
    <td class=xl27126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551 colspan=3><span style='mso-spacerun:yes'>     </span>Центр</td>
    <td colspan=4 class=xl55126551 x:fmla="=E4"><?php echo $centr ; ?></td>
    <td class=xl28126551 colspan=2 x:str="            "><span
  style='mso-spacerun:yes'>            </span></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td colspan=2 class=xl57126551><span style='mso-spacerun:yes'>     </span>ТИП</td>
    <td class=xl57126551></td>
    <td colspan=7 class=xl55126551 x:fmla="=L4"><?php echo $tip ; ?></td>
    <td class=xl27126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Відділ</td>
    <td colspan=4 class=xl36126551 x:fmla="=E5"><?php echo $viddil ; ?></td>
    <td class=xl28126551 colspan=2 x:str="       "><span
  style='mso-spacerun:yes'>       </span></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td colspan=2 class=xl57126551><span style='mso-spacerun:yes'> </span>Модель</td>
    <td class=xl57126551></td>
    <td colspan=7 class=xl36126551 x:fmla="=L5"><?php echo $model ; ?></td>
    <td class=xl27126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl42126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl27126551></td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Група</td>
    <td colspan=4 class=xl55126551 x:fmla="=E7">&nbsp;</td>
    <td class=xl28126551 x:str="     "><span style='mso-spacerun:yes'>     </span></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl63126551></td>
    <td class=xl57126551 x:str="  "><span style='mso-spacerun:yes'>  </span></td>
    <td colspan=4 class=xl57126551>Інвентарн.<span style='mso-spacerun:yes'>  </span>№</td>
    <td colspan=7 class=xl35126551 style='border-right:.5pt solid black;
  border-left:none' x:num x:fmla="=L7"><?php echo $inv ; ?></td>
    <td class=xl31126551 style='border-left:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>                </span>Місто</td>
    <td colspan=4 class=xl36126551 x:fmla="=E8"><?php echo $misto ; ?></td>
    <td class=xl28126551 x:str="    "><span style='mso-spacerun:yes'>    </span></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td colspan=4 class=xl57126551><span style='mso-spacerun:yes'>    </span>Серійний №</td>
    <td colspan=7 class=xl59126551 style='border-right:.5pt solid black;
  border-left:none' x:fmla="=L8"><?php echo $ser ; ?></td>
    <td class=xl31126551 style='border-left:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>          </span>Телефон</td>
    <td colspan=4 class=xl36126551><?php echo $telefon ; ?></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td colspan=4 class=xl57126551>Комплектність</td>
    <td colspan=7 class=xl59126551 style='border-right:.5pt solid black;
  border-left:none' x:fmla="=L9"><?php echo $kompl ; ?></td>
    <td class=xl31126551 style='border-left:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>   </span>Подав заявку</td>
    <td colspan=4 class=xl36126551 x:fmla="=E10"><?php echo $podav ; ?></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td colspan=4 class=xl28126551><span style='mso-spacerun:yes'>       </span>Од.виміру</td>
    <td colspan=7 class=xl59126551 style='border-right:.5pt solid black;
  border-left:none'>шт.</td>
    <td class=xl31126551 style='border-left:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl28126551 colspan=4 style='height:12.75pt'>Прийняв заявку</td>
    <td colspan=4 class=xl36126551 x:str="Канюка " x:fmla="=E11"><?php echo $prinav ; ?></td>
    <td class=xl28126551 x:str="   "><span style='mso-spacerun:yes'>   </span></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td class=xl57126551></td>
    <td colspan="3" class=xl57126551><span style='mso-spacerun:yes'>  </span>Кількість</td>
    <td colspan=7 class=xl59126551 style='border-right:.5pt solid black;
  border-left:none' x:num x:fmla="=L11">1</td>
    <td class=xl31126551 style='border-left:none'>&nbsp;</td>
  </tr>
  <tr height=17 style='height:12.75pt'>
    <td height=17 class=xl27126551 style='height:12.75pt'></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
    <td class=xl28126551></td>
  </tr>
  <![if supportMisalignedColumns]>
  <tr height=0 style='display:none'>
    <td width=68 style='width:20pt'></td>
    <td width=22 style='width:17pt'></td>
    <td width=20 style='width:15pt'></td>
    <td width=22 style='width:17pt'></td>
    <td width=100 style='width:21pt'></td>
    <td width=24 style='width:18pt'></td>
    <td width=24 style='width:18pt'></td>
    <td width=24 style='width:18pt'></td>
    <td width=112 style='width:17pt'></td>
    <td width=19 style='width:14pt'></td>
    <td width=26 style='width:20pt'></td>
    <td width=116 style='width:17pt'></td>
    <td width=23 style='width:17pt'></td>
    <td width=25 style='width:19pt'></td>
    <td width=46 style='width:35pt'></td>
    <td width=6 style='width:5pt'></td>
    <td width=17 style='width:13pt'></td>
    <td width=22 style='width:17pt'></td>
    <td width=23 style='width:17pt'></td>
    <td width=25 style='width:19pt'></td>
    <td width=101 style='width:23pt'></td>
    <td width=24 style='width:18pt'></td>
    <td width=21 style='width:16pt'></td>
    <td width=26 style='width:20pt'></td>
    <td width=41 style='width:31pt'></td>
  </tr>
  <![endif]>
</table>
</div>
<?php pg_close($connection); ?>
<!----------------------------->
<!--КОНЕЦ ФРАГМЕНТА ПУБЛИКАЦИИ МАСТЕРА ВЕБ-СТРАНИЦ EXCEL-->
<!----------------------------->
</body>

</html>


