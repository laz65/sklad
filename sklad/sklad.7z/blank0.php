<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 11">
<link rel=File-List href="Страница.files/filelist.xml">
<style id="Blank_12655_Styles">
<!--table
	{mso-displayed-decimal-separator:"\,";
	mso-displayed-thousand-separator:" ";}
.xl2412655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:14.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl2512655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl2612655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:14.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl2712655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl2812655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl2912655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl3012655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl3112655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:8.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl3212655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:normal;}
.xl3312655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:normal;}
.xl3412655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:normal;}
.xl3512655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl3612655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl3712655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl3812655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl3912655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl4012655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl4112655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4212655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4312655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl4412655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4512655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4612655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4712655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4812655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl4912655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5012655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5112655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5212655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5312655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5412655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5512655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5612655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5712655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5812655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl5912655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6012655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6112655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6212655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6312655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6412655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6512655
	{padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:.5pt solid windowtext;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl39126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:unlocked visible;
	white-space:nowrap;}
.xl25126551 {padding:0px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Times New Roman", serif;
	mso-font-charset:204;
	mso-number-format:"\@";
	text-align:general;
	vertical-align:bottom;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:none;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
--></style>
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);}
o\:* {behavior:url(#default#VML);}
x\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]--></head>

<body>
<!--[if !excel]>&nbsp;&nbsp;<![endif]-->
<!--Следующие сведения были подготовлены мастером публикации веб-страниц
Microsoft Office Excel.-->
<!--При повторной публикации этого документа из Excel все сведения между тегами
DIV будут заменены.-->
<!----------------------------->
<!--НАЧАЛО ФРАГМЕНТА ПУБЛИКАЦИИ МАСТЕРА ВЕБ-СТРАНИЦ EXCEL -->
<!----------------------------->

<div id="Blank_12655" align=center x:publishsource="Excel">
<?php
$sklad_id = $_GET['id'];
$login = $_SERVER['REMOTE_USER'];	
$connection = pg_connect("dbname=asterisk user=asterisk password=12345");
$result2=pg_query($connection, "select * from sklad where sklad_id  = $sklad_id;");
$db2=pg_fetch_array($result2);
$misto = $db2['misto'];
$centr = $db2['centr'];
$viddil = $db2['viddil'];
$telefon = $db2['telefon'];
$podav = $db2['podav'];
$prinav=$db2['prinav'] ;
$prim = $db2['prim'];
$tip = $db2['tip'];
$model = $db2['model'];
$inv = $db2['inv'];
$ser = $db2['ser'];
$kompl = $db2['kompl']; 
$nomer = $db2['nomer']; 
$data = $db2['data_priyom'];
 
 ?>
<table x:str border=0 cellpadding=0 cellspacing=0 width=608 class=xl2812655
 style='border-collapse:collapse;table-layout:fixed;width:462pt'>
 <col class=xl2812655 width=26 style='mso-width-source:userset;mso-width-alt:
 950;width:20pt'>
 <col class=xl2812655 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
 <col class=xl2812655 width=20 style='mso-width-source:userset;mso-width-alt:
 731;width:15pt'>
 <col class=xl2812655 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
 <col class=xl2812655 width=28 style='mso-width-source:userset;mso-width-alt:
 1024;width:21pt'>
 <col class=xl2812655 width=24 span=3 style='mso-width-source:userset;
 mso-width-alt:877;width:18pt'>
 <col class=xl2812655 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
 <col class=xl2812655 width=19 style='mso-width-source:userset;mso-width-alt:
 694;width:14pt'>
 <col class=xl2812655 width=26 style='mso-width-source:userset;mso-width-alt:
 950;width:20pt'>
 <col class=xl2812655 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
 <col class=xl2812655 width=23 style='mso-width-source:userset;mso-width-alt:
 841;width:17pt'>
 <col class=xl2812655 width=25 style='mso-width-source:userset;mso-width-alt:
 914;width:19pt'>
 <col class=xl2812655 width=46 style='mso-width-source:userset;mso-width-alt:
 1682;width:35pt'>
 <col class=xl2812655 width=6 style='mso-width-source:userset;mso-width-alt:
 219;width:5pt'>
 <col class=xl2812655 width=17 style='mso-width-source:userset;mso-width-alt:
 621;width:13pt'>
 <col class=xl2812655 width=22 style='mso-width-source:userset;mso-width-alt:
 804;width:17pt'>
 <col class=xl2812655 width=23 style='mso-width-source:userset;mso-width-alt:
 841;width:17pt'>
 <col class=xl2812655 width=25 style='mso-width-source:userset;mso-width-alt:
 914;width:19pt'>
 <col class=xl2812655 width=30 style='mso-width-source:userset;mso-width-alt:
 1097;width:23pt'>
 <col class=xl2812655 width=24 style='mso-width-source:userset;mso-width-alt:
 877;width:18pt'>
 <col class=xl2812655 width=21 style='mso-width-source:userset;mso-width-alt:
 768;width:16pt'>
 <col class=xl2812655 width=26 style='mso-width-source:userset;mso-width-alt:
 950;width:20pt'>
 <col class=xl2812655 width=41 style='mso-width-source:userset;mso-width-alt:
 1499;width:31pt'>
 
 <tr height=25 style='height:18.75pt'>
  <td height=25 class=xl2412655 colspan=3 width=68 style='height:18.75pt;
  width:52pt'>Наряд</td>
  <td class=xl2512655 width=22 style='width:17pt'>&nbsp;</td>
  <td class=xl2512655 colspan=4 width=100 style='width:75pt'>Замовлення №</td>
  <td colspan=5 class=xl3812655<?php echo $nomer ; ?> width=112 style='border-right:.5pt solid black;
  width:85pt'><div align="center"><?php echo $nomer ; ?></div></td>
  <td class=xl2512655 width=25 style='width:19pt'>&nbsp;</td>
  <td colspan="5" class=xl3912655 style='width:35pt'><form name="form1" method="post" action="spisok.php">
    <span class="xl25126551" style="width:13pt">
    <input type="submit" name="Submit" value="Дубликат">
    </span>
  </form>  </td>
  <td class=xl2512655 width=25 style='width:19pt'>&nbsp;</td>
  <td colspan=4 class=xl3912655 width=101 style='width:77pt' x:num><span class="xl39126551" style="width:77pt"><?php echo $data ; ?></span></td>
  <td class=xl2512655 width=41 style='width:31pt'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2912655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl3012655 colspan=4 style='border-right:.5pt solid black'>Зміст
  заявки</td>
  <td colspan=20 class=xl3812655 style='border-right:.5pt solid black;
  border-left:none'><?php echo $prim ; ?></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl4212655 colspan=3><span
  style='mso-spacerun:yes'> </span>Підрозділ</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4212655 colspan=3><span style='mso-spacerun:yes'> </span>Пристрій</td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl4212655 colspan=9>Комплектуючі та витратні матеріали</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>    
  </span>Центр</td>
  <td colspan=4 class=xl4312655><?php echo $centr ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>           
  </span>ТИП</td>
  <td colspan=4 class=xl4312655><?php echo $tip ; ?></td>
  <td class=xl2812655></td>
  <td class=xl4412655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl4512655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Відділ</td>
  <td colspan=4 class=xl3912655><?php echo $viddil ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>       
  </span>Модель</td>
  <td colspan=4 class=xl3912655><?php echo $model ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl4112655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl4612655>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Група</td>
  <td colspan=4 class=xl4312655>&nbsp;</td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>       
  </span>Інв. №</td>
  <td colspan=4 class=xl3212655 width=116 style='border-right:.5pt solid black;
  width:88pt' x:num><?php echo $inv ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl4112655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>                </span>Місто</td>
  <td colspan=4 class=xl3912655><?php echo $misto ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>      
  </span>Сер. №</td>
  <td colspan=4 class=xl3912655><?php echo $ser ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl4112655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>          </span>Телефон</td>
  <td colspan=4 class=xl3912655><?php echo $telefon ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'> 
  </span>Компл-сть</td>
  <td colspan=4 class=xl3812655 style='border-right:.5pt solid black'><?php echo $kompl ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl4112655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>   </span>Подав заявку</td>
  <td colspan=4 class=xl3912655><?php echo $podav ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>  
  </span>Од.виміру</td>
  <td colspan=4 class=xl3812655 style='border-right:.5pt solid black'>шт.</td>
  <td class=xl2812655></td>
  <td class=xl4612655>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'>Прийняв заявку</td>
  <td colspan=4 class=xl3912655 x:str="Канюка "><?php echo $prinav ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>    
  </span>Кількість</td>
  <td colspan=4 class=xl3812655 style='border-right:.5pt solid black' x:num>1</td>
  <td class=xl2812655></td>
  <td class=xl2912655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl4112655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655
  x:str="                                                                                                                                                                                                                                                                                  "></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4412655 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black'><span style='mso-spacerun:yes'> </span>Виконавец<span
  style='display:none'>ь</span></td>
  <td class=xl4412655 colspan=3 style='border-right:.5pt solid black'>Дата
  початку</td>
  <td class=xl4412655 colspan=4 style='border-right:.5pt solid black'>Дата
  закінчення</td>
  <td colspan=7 rowspan=2 class=xl4812655 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'><span style='mso-spacerun:yes'>   
  </span>Діагноз та виконані роботи</td>
  <td colspan=6 rowspan=2 class=xl4812655 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'><span style='mso-spacerun:yes'>  
  </span>Затрачені матеріали</td>
  <td colspan=2 class=xl4812655 style='border-right:.5pt solid black;
  border-left:none'><span style='mso-spacerun:yes'>     </span>Підпис</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl5312655 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black'><span style='mso-spacerun:yes'>     </span>(П.І.Б.)</td>
  <td class=xl5312655 colspan=3 style='border-right:.5pt solid black'><span
  style='mso-spacerun:yes'>     </span>роботи</td>
  <td class=xl5312655 colspan=3><span style='mso-spacerun:yes'>      
  </span>роботи</td>
  <td class=xl5212655>&nbsp;</td>
  <td colspan=2 class=xl5412655 style='border-right:.5pt solid black;
  border-left:none'>виконавця</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4412655 style='height:12.75pt;border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4612655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl5312655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5312655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4412655 style='height:12.75pt;border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4412655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4612655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4612655>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4612655>&nbsp;</td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl5812655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5412655>&nbsp;</td>
  <td class=xl5512655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5312655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4412655 style='height:12.75pt;border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-left:none'>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl4512655>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4612655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
  <td class=xl4612655 style='border-left:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4612655>&nbsp;</td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl5312655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5312655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2512655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height=25 class=xl2612655 colspan=6 style='height:18.75pt'>Картка видачі</td>
  <td class=xl2812655 colspan=4>Замовлення №</td>
  <td colspan=3 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=I1"><?php echo $nomer ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2812655 colspan=6><span style='mso-spacerun:yes'> </span>Дата та
  час приймання</td>
  <td colspan=4 class=xl5712655 x:num x:fmla="=U1"><?php echo $data ; ?></td>
  <td class=xl2812655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl4212655 colspan=3><span
  style='mso-spacerun:yes'> </span>Підрозділ</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4212655 colspan=3><div align="center"><span style='mso-spacerun:yes'> </span>Пристрій</div></td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl4212655 colspan=9>Комплектуючі та витратні матеріали</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>    
  </span>Центр</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=E4"><?php echo $centr ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>           
  </span>ТИП</td>
  <td colspan=4 class=xl5512655 x:fmla="=L4"><?php echo $tip ; ?></td>
  <td class=xl2812655></td>
  <td class=xl4412655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl4512655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Відділ</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=E5"><?php echo $viddil ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>       
  </span>Модель</td>
  <td colspan=4 class=xl3612655 x:fmla="=L5"><?php echo $model ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl4112655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl4612655>&nbsp;</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4712655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Група</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=E7"><?php echo $grupa ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>       
  </span>Інв. №</td>
  <td colspan=4 class=xl3512655 style='border-right:.5pt solid black' x:num
  x:fmla="=L7"><?php echo $inv ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl3012655>&nbsp;</td>
  <td class=xl4112655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>                </span>Місто</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=E8"><?php echo $misto ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>      
  </span>Сер. №</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=L8"><?php echo $ser ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl4112655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>          </span>Телефон</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=E9"><?php echo $telefon ; ?></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'> 
  </span>Компл-сть</td>
  <td colspan=4 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=L9"><?php echo $kompl ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2912655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl3012655 style='border-top:none'>&nbsp;</td>
  <td class=xl4112655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4412655 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black' x:str="№ наклдн / ">№ наклдн /<span
  style='mso-spacerun:yes'> </span></td>
  <td class=xl4412655 colspan=10>Дата-час отримання послуги обо пристр<span
  style='display:none'>ою</span></td>
  <td colspan=8 rowspan=2 class=xl4812655 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'><span style='mso-spacerun:yes'>  
  </span>Отримав (П.І.Б. замовника)</td>
  <td colspan=4 rowspan=2 class=xl4812655 style='border-right:.5pt solid black;
  border-bottom:.5pt solid black'>Підпис замовника</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl5312655 colspan=3 style='height:12.75pt;border-right:
  .5pt solid black'><span style='mso-spacerun:yes'> </span>№ запису</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655 colspan=8><span style='mso-spacerun:yes'>  
  </span>(заповнюється замовником)</td>
  <td class=xl5112655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl4412655 style='height:12.75pt;border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4412655 style='border-top:none;border-left:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl2512655 style='border-top:none'>&nbsp;</td>
  <td class=xl4512655 style='border-top:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl5312655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
  <td class=xl5312655 style='border-left:none'>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5112655>&nbsp;</td>
  <td class=xl5212655>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655 colspan=7 x:str="Черговий сектору ТЗ та ОК ">Черговий
  сектору ТЗ та ОК<span style='mso-spacerun:yes'> </span></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'> </span>ЦІТіТЗ</td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl6212655 style='height:12.75pt'>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
  <td class=xl2512655>&nbsp;</td>
 </tr>
 <tr height=25 style='height:18.75pt'>
  <td height=25 class=xl2612655 colspan=4 style='height:18.75pt'>Розписка</td>
  <td class=xl2812655 colspan=4>Замовлення №</td>
  <td colspan=3 class=xl5912655 style='border-right:.5pt solid black'
  x:fmla="=I1"><?php echo $nomer ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655 colspan=6>Дата та час приймання</td>
  <td colspan=4 class=xl5712655 x:num x:fmla="=U1"><?php echo $data ; ?></td>
  <td class=xl2712655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655 colspan=3><span style='mso-spacerun:yes'>    
  </span>Центр</td>
  <td colspan=4 class=xl5512655 x:fmla="=E4"><?php echo $centr ; ?></td>
  <td class=xl2812655 colspan=2 x:str="            "><span
  style='mso-spacerun:yes'>            </span></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td colspan=2 class=xl5712655><span style='mso-spacerun:yes'>     </span>ТИП</td>
  <td class=xl5712655></td>
  <td colspan=7 class=xl5512655 x:fmla="=L4"><?php echo $tip ; ?></td>
  <td class=xl2712655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Відділ</td>
  <td colspan=4 class=xl3612655 x:fmla="=E5"><?php echo $viddil ; ?></td>
  <td class=xl2812655 colspan=2 x:str="       "><span
  style='mso-spacerun:yes'>       </span></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td colspan=2 class=xl5712655><span style='mso-spacerun:yes'> </span>Модель</td>
  <td class=xl5712655></td>
  <td colspan=7 class=xl3612655 x:fmla="=L5"><?php echo $model ; ?></td>
  <td class=xl2712655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl4212655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2712655></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>               </span>Група</td>
  <td colspan=4 class=xl5512655 x:fmla="=E7">&nbsp;</td>
  <td class=xl2812655 x:str="     "><span style='mso-spacerun:yes'>     </span></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl6312655></td>
  <td class=xl5712655 x:str="  "><span style='mso-spacerun:yes'>  </span></td>
  <td colspan=4 class=xl5712655>Інвентарн.<span style='mso-spacerun:yes'> 
  </span>№</td>
  <td colspan=7 class=xl3512655 style='border-right:.5pt solid black;
  border-left:none' x:num x:fmla="=L7"><?php echo $inv ; ?></td>
  <td class=xl3112655 style='border-left:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>                </span>Місто</td>
  <td colspan=4 class=xl3612655 x:fmla="=E8"><?php echo $misto ; ?></td>
  <td class=xl2812655 x:str="    "><span style='mso-spacerun:yes'>    </span></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td colspan=4 class=xl5712655><span style='mso-spacerun:yes'>   
  </span>Серійний №</td>
  <td colspan=7 class=xl5912655 style='border-right:.5pt solid black;
  border-left:none' x:fmla="=L8"><?php echo $ser ; ?></td>
  <td class=xl3112655 style='border-left:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>          </span>Телефон</td>
  <td colspan=4 class=xl3612655><?php echo $telefon ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td colspan=4 class=xl5712655>Комплектність</td>
  <td colspan=7 class=xl5912655 style='border-right:.5pt solid black;
  border-left:none' x:fmla="=L9"><?php echo $kompl ; ?></td>
  <td class=xl3112655 style='border-left:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'><span
  style='mso-spacerun:yes'>   </span>Подав заявку</td>
  <td colspan=4 class=xl3612655 x:fmla="=E10"><?php echo $podav ; ?></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td colspan=4 class=xl2812655><span style='mso-spacerun:yes'>      
  </span>Од.виміру</td>
  <td colspan=7 class=xl5912655 style='border-right:.5pt solid black;
  border-left:none'>шт.</td>
  <td class=xl3112655 style='border-left:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2812655 colspan=4 style='height:12.75pt'>Прийняв заявку</td>
  <td colspan=4 class=xl3612655 x:str="Канюка " x:fmla="=E11"><?php echo $prinav ; ?></span></td>
  <td class=xl2812655 x:str="   "><span style='mso-spacerun:yes'>   </span></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl5712655></td>
  <td class=xl5712655></td>
  <td colspan="4" class=xl5712655><span style='mso-spacerun:yes'>  </span>Кількість</td>
  <td colspan=7 class=xl5912655 style='border-right:.5pt solid black;
  border-left:none' x:num x:fmla="=L11">1</td>
  <td class=xl3112655 style='border-left:none'>&nbsp;</td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl2712655 style='height:12.75pt'></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
  <td class=xl2812655></td>
 </tr>
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=68 style='width:20pt'></td>
  <td width=22 style='width:17pt'></td>
  <td width=20 style='width:15pt'></td>
  <td width=22 style='width:17pt'></td>
  <td width=100 style='width:21pt'></td>
  <td width=24 style='width:18pt'></td>
  <td width=24 style='width:18pt'></td>
  <td width=24 style='width:18pt'></td>
  <td width=112 style='width:17pt'></td>
  <td width=19 style='width:14pt'></td>
  <td width=26 style='width:20pt'></td>
  <td width=116 style='width:17pt'></td>
  <td width=23 style='width:17pt'></td>
  <td width=25 style='width:19pt'></td>
  <td width=46 style='width:35pt'></td>
  <td width=6 style='width:5pt'></td>
  <td width=17 style='width:13pt'></td>
  <td width=22 style='width:17pt'></td>
  <td width=23 style='width:17pt'></td>
  <td width=25 style='width:19pt'></td>
  <td width=101 style='width:23pt'></td>
  <td width=24 style='width:18pt'></td>
  <td width=21 style='width:16pt'></td>
  <td width=26 style='width:20pt'></td>
  <td width=41 style='width:31pt'></td>
 </tr>
 <![endif]>
</table>

</div>
<?php pg_close($connection); ?>

<!----------------------------->
<!--КОНЕЦ ФРАГМЕНТА ПУБЛИКАЦИИ МАСТЕРА ВЕБ-СТРАНИЦ EXCEL-->
<!----------------------------->
</body>

</html>


